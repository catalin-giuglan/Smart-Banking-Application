package org.poo.cb;

import java.util.ArrayList;

public abstract class Command {
	public abstract void execute(ArrayList<String> args);
}
